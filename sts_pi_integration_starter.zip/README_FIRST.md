# STS Pi integration starter kit

Start with `PI_INTEGRATION_HANDOFF.md`.

This archive is a **starter kit plus implementation specification**, not a drop-in replacement for the current orchestration.

Recommended use:

```bash
# from sts_ai root
unzip /path/to/sts_pi_integration.zip -d /tmp/sts-pi-kit
cp -a /tmp/sts-pi-kit/.pi .
cp -a /tmp/sts-pi-kit/scripts/install_pi_subagent.sh scripts/
cp -a /tmp/sts-pi-kit/scripts/check_pi_setup.sh scripts/
cp /tmp/sts-pi-kit/PI_INTEGRATION_HANDOFF.md .

bash scripts/install_pi_subagent.sh
bash scripts/check_pi_setup.sh
```

Then give `PI_INTEGRATION_HANDOFF.md` to the CLI coding agent and tell it to implement the migration incrementally.

Do not delete `tools/ai_cycle.py` or the OpenCode backend during the first migration commit.
