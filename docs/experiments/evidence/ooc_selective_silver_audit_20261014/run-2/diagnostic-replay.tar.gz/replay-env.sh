#!/bin/bash
# usage: run.sh BINARY SEED OUTPREFIX
cd /home/user/sts_ai
BIN=$1; SEED=$2; OUT=$3
python3 - "$BIN" "$SEED" "$OUT" <<'PY'
import json,os,subprocess,sys
b,s,o=sys.argv[1:]
f=json.load(open('/tmp/claude-0/ev/run2/freeze.json'))
env=dict(f['environment']); env['HOME']=os.environ['HOME']
env['STS_SILVER_ROOT_PRIOR']='/home/user/sts_ai/docs/experiments/evidence/silver_prior_arch_20261014/models/gen6/combat_policy_mlp_g6_E.txt'
[env.__setitem__(k,v) for k,v in os.environ.items() if k.startswith('STS_SIM_HEALTH')]; env['STS_EXECUTABLE_GIT_SHA']=os.environ.get('SHA','diag')
argv=['bash','tools/seed_guard.sh',b,'oocselectivesilvergen','1',s,'/tmp/claude-0/ev/run2/plan.json',o+'.jsonl']
with open(o+'.log','w') as log:
  r=subprocess.run(['prlimit','--cpu=400:400','--',*argv],env=env,stdout=log,stderr=subprocess.STDOUT)
print('rc',r.returncode)
PY
