#!/usr/bin/env python3
"""Seed-free actual-artifact parity: synthetic feature arrays, no game state/run.

prepare MODEL OUTDIR writes fixtures and NumPy reference; run BINARY OUTDIR
invokes only silverpolicymlpcheck after a separately authorized build is ready.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess

import numpy as np

EXPECTED_SHA = "ca9bd7f25cd2fb5c3e82609c35077e1c55d40c3f9c3d27da8e87236997b33228"
ATOL, RTOL = 1e-4, 1e-5


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def dump_new(path, value):
    with Path(path).open("x") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")


def parse_model(path):
    assert sha(path) == EXPECTED_SHA, "wrong generation 6 E artifact"
    tokens = iter(Path(path).read_text().split())
    assert next(tokens) == "combat_policy_mlp_v2"
    dims = {}
    for key in ("h1", "h2", "nstate", "naction", "ncard", "ntarget"):
        assert next(tokens) == key
        dims[key] = int(next(tokens))
    assert dims == dict(h1=128, h2=64, nstate=1766, naction=22, ncard=372, ntarget=9)
    names = []
    for _ in range(dims["nstate"] + dims["naction"]):
        assert next(tokens) == "feat"
        names.append(next(tokens))
    h1, h2 = dims["h1"], dims["h2"]
    shapes = {"state_w": (dims["nstate"], h1), "action_w": (dims["naction"], h1),
              "card": (dims["ncard"], h1), "target_w": (dims["ntarget"], h1),
              "b1": (h1,), "w2": (h2, h1), "b2": (h2,), "w3": (h2,), "b3": (1,)}
    weights = {}
    for key, shape in shapes.items():
        assert next(tokens) == key
        # Native storage is float32. Accumulate independently in float64.
        weights[key] = np.asarray([float(next(tokens)) for _ in range(int(np.prod(shape)))],
                                  dtype=np.float32).astype(np.float64).reshape(shape)
    for key in tokens:
        assert key in ("enc", "mon_id", "mon_dmg") and key not in weights
        assert int(next(tokens)) == 128
        weights[key] = np.asarray([float(next(tokens)) for _ in range(128 * h1)],
                                  dtype=np.float32).astype(np.float64).reshape(128, h1)
    assert set(weights) == set(shapes) | {"enc", "mon_id", "mon_dmg"}
    assert all(np.isfinite(w).all() for w in weights.values())
    return dims, names, weights


def fixtures(dims, names):
    ns, na = dims["nstate"], dims["naction"]
    si = {name: i for i, name in enumerate(names[:ns])}
    ai = {name: i for i, name in enumerate(names[ns:])}
    assert si["encounter"] == 1 and ai["aCardId"] == 4
    variants = [
        ("ordinary_and_empty_slot", {"encounter": 5, "m0Id": 7, "m0Intent": 3, "m1Id": -1, "m1Intent": 99}),
        ("encounter_lower_clip", {"encounter": -5, "m0Id": 7, "m0Intent": 3}),
        ("encounter_upper_clip", {"encounter": 300, "m0Id": 7, "m0Intent": 3}),
        ("id_zero_skips_embeddings", {"encounter": 5, "m0Id": 0, "m0Intent": 99}),
        ("two_occupied_damage_clip", {"encounter": 5, "m0Id": 7, "m0Intent": 3,
                                      "m1Id": 12, "m1Hp": 30, "m1Intent": 300}),
        ("negative_damage_clip", {"encounter": 5, "m0Id": 7, "m0Intent": -7}),
        ("monster_id_upper_clip", {"encounter": 127, "m0Id": 140, "m0Intent": 127}),
        ("all_empty_skip_embeddings", {"encounter": 0, "m0Id": -1, "m0Intent": 127}),
    ]
    actions = [
        ("end_turn_no_card", -1, {"aIsEndTurn": 1, "aCardId": -1}),
        ("card_target_zero", 0, {"aIsCard": 1, "aCardId": 1, "aCardCost": 1,
                                  "aCardAtk": 1, "aTargetsEnemy": 1, "aTargetHp": 40}),
        ("card_target_one", 1, {"aIsCard": 1, "aCardId": 25, "aCardCost": 2,
                                 "aCardUpg": 1, "aCardSkl": 1, "aTargetsEnemy": 1, "aTargetHp": 30}),
        ("highest_card_no_target", -1, {"aIsCard": 1, "aCardId": 370, "aCardPow": 1, "aCardCost": 3}),
        ("invalid_card_fallback", -1, {"aIsSelect": 1, "aCardId": 999, "aSelectSize": 2}),
    ]
    result = []
    for label, overrides in variants:
        state = np.zeros(ns, np.float32)
        base = dict(ascension=20, turn=2, curHp=60, maxHp=80, energy=3,
                    strength=2, hand=5, draw=6, discard=3, monAlive=1, monSumHp=40,
                    m0Hp=40, m0Atk=1, gold=100, potionCap=3)
        base.update({f"m{k}Id": -1 for k in range(5)})
        base.update(overrides)
        for name, value in base.items():
            state[si[name]] = value
        edges = []
        for action_name, target, features in actions:
            action = np.zeros(na, np.float32)
            for name, value in features.items():
                action[ai[name]] = value
            edges.append((action_name, target, action))
        result.append((label, state, edges))
    return result


def reference(dims, names, weights, cases):
    si = {name: i for i, name in enumerate(names[:dims["nstate"]])}
    values, labels = [], []
    def table_row(value):
        assert float(value).is_integer()  # synthetic inputs avoid rounding ties
        return min(127, max(0, int(value)))
    for label, state, edges in cases:
        x = state.astype(np.float64)
        base = weights["b1"] + x @ weights["state_w"]
        base = base + weights["enc"][table_row(x[si["encounter"]])]
        for k in range(5):
            monster = x[si[f"m{k}Id"]]
            if monster <= 0:
                continue
            base = base + weights["mon_id"][table_row(monster + 1)]
            base = base + weights["mon_dmg"][table_row(x[si[f"m{k}Intent"]])]
        for action_name, target, action in edges:
            ac = action.astype(np.float64)
            card = int(ac[4]) + 1
            if card < 0 or card >= dims["ncard"]:
                card = 0
            hidden = base + ac @ weights["action_w"] + weights["card"][card]
            if target >= 0:
                start = si[f"m{target}Id"]
                hidden = hidden + x[start:start + dims["ntarget"]] @ weights["target_w"]
            z = np.maximum(0, weights["w2"] @ np.maximum(0, hidden) + weights["b2"])
            values.append(float(z @ weights["w3"] + weights["b3"][0]))
            labels.append(dict(case=label, action=action_name, target=target))
    return np.asarray(values), labels


def prepare(model, out):
    out.mkdir(parents=True, exist_ok=True)
    dims, names, weights = parse_model(model)
    cases = fixtures(dims, names)
    values, labels = reference(dims, names, weights, cases)
    nnz, indices, sparse, meta = [], [], [], []
    for _, state, edges in cases:
        nz = np.flatnonzero(state)
        nnz.append(len(nz)); indices.extend(nz); sparse.extend(state[nz]); meta.append({"k": "state"})
        for _, target, action in edges:
            nz = np.flatnonzero(action)
            nnz.append(len(nz)); indices.extend(nz + dims["nstate"]); sparse.extend(action[nz])
            meta.append({"k": "act", "tgt": target, "visits": 1})
    prefix = out / "synthetic"
    for suffix, data, dtype in (("nnz", nnz, "<u4"), ("idx", indices, "<u2"), ("val", sparse, "<f4")):
        with Path(str(prefix) + "." + suffix).open("xb") as stream:
            stream.write(np.asarray(data, dtype=dtype).tobytes())
    with Path(str(prefix) + ".meta.jsonl").open("x") as stream:
        for row in meta:
            stream.write(json.dumps(row) + "\n")
    dump_new(out / "reference.json", {"logits": values.tolist(), "labels": labels})
    files = [out / "reference.json", *sorted(out.glob("synthetic.*")), Path(__file__).resolve()]
    dump_new(out / "manifest.json", {"schema": "gen6_e_synthetic_native_parity_v1", "model": str(model),
             "modelSha256": sha(model), "dimensions": dims, "tables": ["enc", "mon_id", "mon_dmg"],
             "roots": len(cases), "edges": len(values), "atol": ATOL, "rtol": RTOL,
             "noGameplay": True, "inputHashes": {str(p): sha(p) for p in files}})
    print(json.dumps({"prepared": str(out), "roots": len(cases), "edges": len(values)}))


def run(binary, out):
    manifest = json.loads((out / "manifest.json").read_text())
    assert manifest["atol"] == ATOL and manifest["rtol"] == RTOL
    assert sha(manifest["model"]) == manifest["modelSha256"] == EXPECTED_SHA
    assert all(sha(p) == digest for p, digest in manifest["inputHashes"].items())
    output = out / "native-logits.txt"
    assert not output.exists() and not (out / "result.json").exists()
    argv = [str(binary), "silverpolicymlpcheck", manifest["model"], str(out / "synthetic"), str(output)]
    env = {"PATH": "/usr/local/bin:/usr/bin:/bin", "HOME": os.environ["HOME"],
           "OMP_NUM_THREADS": "1", "OMP_DYNAMIC": "FALSE"}
    binary_hash = sha(binary)
    with (out / "native.log").open("x") as log:
        process = subprocess.run(argv, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=30)
    assert process.returncode == 0, f"native check failed: {process.returncode}"
    binary_hash_after = sha(binary)
    assert binary_hash_after == binary_hash, "binary changed during parity check"
    expected = json.loads((out / "reference.json").read_text())
    actual = np.atleast_1d(np.loadtxt(output))
    ref = np.asarray(expected["logits"])
    assert actual.shape == ref.shape and np.isfinite(actual).all()
    error = np.abs(actual - ref)
    tolerance = ATOL + RTOL * np.abs(ref)
    passed = bool(np.all(error <= tolerance))
    result = {"verdict": "PASS" if passed else "FAIL", "argv": argv, "binarySha256": binary_hash,
              "binarySha256After": binary_hash_after,
              "modelSha256": EXPECTED_SHA, "manifestSha256": sha(out / "manifest.json"),
              "helperSha256": sha(__file__), "roots": manifest["roots"], "edges": int(ref.size),
              "atol": ATOL, "rtol": RTOL, "maxAbsError": float(error.max()),
              "maxRelativeError": float(np.max(error / np.maximum(np.abs(ref), 1e-12))),
              "maxToleranceFraction": float(np.max(error / tolerance)), "noGameplay": True,
              "rows": [dict(label, native=float(n), numpy=float(r), absError=float(e))
                       for label, n, r, e in zip(expected["labels"], actual, ref, error)]}
    dump_new(out / "result.json", result)
    print(json.dumps({key: value for key, value in result.items() if key != "rows"}))
    return 0 if passed else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("prepare", "run"))
    parser.add_argument("input", type=Path)
    parser.add_argument("out", type=Path)
    args = parser.parse_args()
    if args.mode == "prepare":
        prepare(args.input.resolve(), args.out.resolve())
        return 0
    return run(args.input.resolve(), args.out.resolve())


if __name__ == "__main__":
    raise SystemExit(main())
