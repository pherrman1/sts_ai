"""Review diagnostic (post hoc): arms A and C with E3's weight normalization."""
import sys, json, hashlib, numpy as np, xgboost as xgb
from tools.vwin_e3_cf import HIDDEN_FUTURE, load_trees, metrics, cluster_mean
from tools.vwin_a20_transfer import prepare, fit, row_loss
a0r, a20r, out = sys.argv[1:4]
names, _ = load_trees()
public = [n for n in names if n not in HIDDEN_FUTURE] + ["ascension"]
a0, w0, _, _ = prepare(a0r, names); a20, w20, _, _ = prepare(a20r, names)
c = len(w0) / w0.sum()          # E3: w *= len(w)/w.sum() over the A0 corpus
print("mean A0 weight before", w0.mean(), "scale", c)
X0, y0 = a0[public].to_numpy(np.float32), a0["finalWon"].to_numpy(np.float32)
X20, y20 = a20[public].to_numpy(np.float32), a20["finalWon"].to_numpy(np.float32)
tr, va = (a0["split"] == "TRAIN").to_numpy(), (a0["split"] == "VALIDATION").to_numpy()
src = sorted(a0.loc[tr, "sourceSeed"].unique(), key=lambda s: hashlib.sha256(f"e3-curve-v1:{s}".encode()).hexdigest())
d0 = xgb.DMatrix(X0[va], feature_names=public); yv = y0[va].astype(float); sv = a0.loc[va, "sourceSeed"].to_numpy()
res = {}
va20 = (a20["split"] == "VALIDATION").to_numpy()
for scale in (c,):
    pre = {s: fit(X20[~va20], y20[~va20], w20[~va20]*scale, X20[va20], y20[va20], w20[va20]*scale, public, s, 4, 2500)[0] for s in (0,1,2)}
    for f in (0.10, 0.25, 0.50, 1.0):
        keep = set(src[:max(1, int(round(f * len(src))))]); sel = tr & a0["sourceSeed"].isin(keep).to_numpy()
        P = {}
        for arm in ("A", "C", "B"):
            X, y, w = (X0[sel], y0[sel], w0[sel] * scale)
            if arm == "C":
                X, y, w = np.concatenate([X, X20]), np.concatenate([y, y20]), np.concatenate([w, w20 * scale])
            ps, ts = [], []
            for s in (0, 1, 2):
                b, n = fit(X0[sel], y0[sel], w0[sel]*scale, X0[va], y0[va], w0[va] * scale, public, s, 4, 2500, base=pre[s]) if arm == "B" else fit(X, y, w, X0[va], y0[va], w0[va] * scale, public, s, 4, 2500)
                ps.append(b.predict(d0)); ts.append(n)
            P[arm] = np.mean(ps, axis=0)
            res[f"{arm}_{int(f*100)}_scale{scale:.2f}"] = dict(nll=metrics(yv, P[arm])["nll"], trees=ts)
        d = cluster_mean(row_loss(yv, P["C"]) - row_loss(yv, P["A"]), sv, 2000)
        res[f"CminusA_{int(f*100)}_scale{scale:.2f}"] = d
        res[f"BminusA_{int(f*100)}_scale{scale:.2f}"] = cluster_mean(row_loss(yv, P["B"]) - row_loss(yv, P["A"]), sv, 2000)
        print("B", res[f"B_{int(f*100)}_scale{scale:.2f}"], res[f"BminusA_{int(f*100)}_scale{scale:.2f}"])
        print(f, scale, res[f"A_{int(f*100)}_scale{scale:.2f}"], res[f"C_{int(f*100)}_scale{scale:.2f}"], d, flush=True)
json.dump(res, open(out, "w"), indent=1, default=float)
