Independent review rerun of PR #464 head 2bf07e3d (thread cmsg_01Gm4mB9c3iJfz3vtwJcJzmnGPQg8YJAJuzkDv6vAcWHXi)
