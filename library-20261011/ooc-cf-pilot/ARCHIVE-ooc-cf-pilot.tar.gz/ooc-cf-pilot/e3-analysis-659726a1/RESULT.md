# E3 interim result (cloud arms, VALIDATION only, TEST closed)

## Corpus and run

- **Corpus:** 25 workers on 1,000 seeds (55000000..999). 199 of 200 parts
  finished; w20 chunk1/part2 (55000830..834) stalled and is excluded.
- **Runs:** 15,667 of 15,668 valid; 1 (state, k) group was dropped.
- **Provenance:** every part comes from git 8edf724c and binary 224a1a42…
- **States:** 1,983 in total, split TRAIN 1,380, VALIDATION 333, TEST 270.

  | Type | Act 1 | Act 2 | Act 3 |
  |---|---|---|---|
  | Card reward | 374 | 322 | 299 |
  | Boss relic | 557 | 431 | — |

- **Tool:** `tools/vwin_e3_cf.py` at 659726a1. Report: `report.json`. The
  data rules follow E3-PREREG.md.

## Selection gain vs V4

Columns:
- **Win-rate change vs V4:** win rate of the model's pick minus V4's pick,
  over K=2 runs. Per state, with a source-clustered 95% CI.
- **Agrees with V4:** share of states where the model picks V4's option.
- **Picks skip:** share of states where the model picks skip.

| Arm | Type | Win-rate change vs V4 | Agrees with V4 | Picks skip |
|---|---|---|---|---|
| X2-B (four fields masked) | Card reward | +0.002 [−0.035, +0.038] | 0.24 | 0.24 |
| | Boss relic | **−0.048 [−0.093, −0.003]** | 0.36 | 0.14 |
| E3-only GBM (X2-B recipe, 457 public features) | Card reward | +0.010 [−0.028, +0.049] | 0.26 | 0.21 |
| | Boss relic | +0.011 [−0.027, +0.047] | 0.57 | 0.02 |
| E3 − X2-B | Card reward | +0.008 [−0.021, +0.039] | | |
| | Boss relic | **+0.059 [+0.018, +0.099]** | | |
| Uniform random option | Card reward | −0.001 [−0.027, +0.026] | | |
| | Boss relic | −0.090 [−0.124, −0.055] | | |
| Oracle (best of K=2, noise-inflated) | Card reward | +0.114 | | |
| | Boss relic | +0.108 | | |

Map-row NLL/Brier: X2-B 0.4957/0.1591, E3 0.4854/0.1577.

Learning curve for E3 at 25/50/100% of TRAIN sources:

| Metric | 25% | 50% | 100% |
|---|---|---|---|
| NLL | 0.4936 | 0.4824 | 0.4854 |
| Card-reward gain | +0.005 | −0.004 | +0.010 |

## Reading

- **Card rewards:** no arm beats V4. Even a uniformly random card-reward
  option scores the same as V4 (−0.001, CI ±0.027).
  - Inference: under the V4 + Silver continuation, the win-rate effect of
    which card is picked is below roughly 3 pp per decision, too small to
    detect with 167 VALIDATION states at K=2.
  - The new data does not make card picks learnable at this size.
- **Boss relics** matter: a random relic loses 9 pp.
  - X2-B picks worse than V4 (−4.8 pp).
  - A GBM trained on E3 alone matches V4 and beats X2-B by +5.9 pp, with a
    CI above zero.
- **The pre-registered decision arm is F2:** #334 TRAIN with focal rows
  upweighted, plus E3 TRAIN. It needs the #334 corpus on Philipp's machine:
  `python3 -m tools.vwin_e3_cf E3_DIR --corpus334 INDEX --output NEW` (at
  dc6fd330).
  - The E3 data is `export/e3-corpus.tgz`, sha256 `b9599bf3…`.
  - Given the E3-only result and a learning curve that is not rising, F2 is
    unlikely to pass the card-reward criterion. The rule then says negative
    for card rewards. Inference.
