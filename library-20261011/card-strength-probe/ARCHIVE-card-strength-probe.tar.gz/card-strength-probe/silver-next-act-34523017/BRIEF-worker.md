# Worker brief: A20 Silver card strength with next act (§420 follow-up, full 970 states)

You are strength worker W (W = 00..15, given in your start message). Philipp authorized this run
(2026-10-10 07:42Z: "Merge, then add next act and scale"). Owning thread: "Why OOC MCTS misjudges cards".
Plan (frozen): docs/experiments/evidence/a20_card_floor_20261009/PLAN-SILVER-NEXT-ACT.md at the commit below.
Do not change code, do not open PRs, do not score or analyse, do not write anywhere except your own output folder.
When done, reply in your thread with the 3-line summary at the end.

## Frozen inputs

- Repo https://github.com/pherrman1/sts_ai, branch `claude/project-thread-3cdw63`, commit
  `3452301730dfb756eb34d08f60cec7a9fe4012aa`. No code change.
- Release `one_combat` built from that commit must have sha256
  `187fa5e1b2c3a9022852981cd4f8fdffe5d099526883973560f245b25a2836a5` (Release builds are bit-reproducible).
  If it differs, STOP and report.
- Seeds: only those in `docs/experiments/evidence/a20_card_floor_20261009/silver_next_act_seeds/wWW.txt`
  (about 61 existing corpus seeds; no new seeds).

## Setup (cloud container, 4 CPUs)

```bash
cd ~ && git clone https://github.com/pherrman1/sts_ai.git sts && cd sts    # or reuse a checkout
git fetch origin claude/project-thread-3cdw63
git checkout --detach 3452301730dfb756eb34d08f60cec7a9fe4012aa
git submodule update --init --recursive
cmake --preset linux-gcc-release
cmake --build build/linux-gcc-release --target one_combat -j4      # ~4-5 min
sha256sum build/linux-gcc-release/one_combat                        # must be 187fa5e1...
```

## Run (from the repo root; the runner copies the binary to a local temp dir, so noexec on /mnt/project-files is fine)

```bash
W=WW   # your two-digit worker number
OUT=/mnt/project-files/card-strength-probe/silver-next-act-34523017/w$W
nohup bash docs/experiments/evidence/a20_card_floor_20261009/run_strength.sh \
  build/linux-gcc-release/one_combat 3452301730dfb756eb34d08f60cec7a9fe4012aa "$OUT" \
  59100000 1200 4 docs/experiments/evidence/a20_card_floor_20261009/silver_next_act_seeds/w$W.txt 1 1 \
  > ~/strength-w$W.log 2>&1 &
```

- Every seed goes through tools/seed_guard.sh inside the runner. TEST seeds are skipped by the runner.
- Expected: about 25-40 minutes. `$OUT/DONE` appears when finished. Rerunning the same command resumes
  (finished seeds have a manifest and are skipped).
- IMPORTANT: idle cloud containers get reclaimed and kill nohup'd runs. Keep a background Bash watcher
  running until `$OUT/DONE` exists, e.g. `until [ -f "$OUT/DONE" ]; do sleep 60; done` with
  run_in_background and a 2 h timeout. If the container restarts, rerun the same command (it resumes).

## When `$OUT/DONE` exists, reply in your thread with

```
W=..  manifests=<ls $OUT/part*.manifest.json | wc -l> / seeds in list=<wc -l of wWW.txt minus TEST skips>  logs with "exit"=<grep -l "^exit" $OUT/*.log | wc -l>
binary sha ok: yes/no
output: /mnt/project-files/card-strength-probe/silver-next-act-34523017/wWW
```
